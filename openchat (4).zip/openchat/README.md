# OpenChat: self-hosted WhatsApp team inbox

Shared inbox, unlimited teammates, consent-only campaigns with variables, keyword automations, catalogue, public opt-in form, chat assignment, CSV upload and optional Claude AI replies. Uses the **official WhatsApp Cloud API**, which is what keeps numbers safe.

## 1. Meta setup (one time)
1. Create a Meta developer app, add WhatsApp, verify your business in Business Manager.
2. Put the Phone Number ID, a permanent System User token and the App Secret in `.env` (copy `.env.example`).
3. Webhook: callback `https://chat.yourdomain.com/webhook`, verify token = `VERIFY_TOKEN`, subscribe to **messages**.
4. Create templates in Meta and get them approved. For variables use `{{1}}`; in Campaigns type the values in order, e.g. `name, 20% off` (`name` is replaced with each contact's name).

## 2. Hosting for free: pick one
**Do not use Render's free tier.** It sleeps after 15 minutes (WhatsApp messages and queued campaigns stall) and wipes local files, including this app's database, on every restart.

**A. Your own always-on computer + Cloudflare Tunnel (free).** Works behind home internet, with free HTTPS.
1. Install Node 20.6+. Unzip `openchat.zip`, then: `cd openchat && npm install && cp .env.example .env` and fill in `.env`.
2. Run it permanently: `npm i -g pm2 && pm2 start server.js --name openchat --node-args="--env-file=.env" && pm2 save` (then `pm2 startup`).
3. Add your domain to a free Cloudflare account and change the nameservers at GoDaddy to the two Cloudflare gives you.
4. Install `cloudflared`, create a tunnel, and route `chat.yourdomain.com` to `http://localhost:3000` (Cloudflare Zero Trust, Networks, Tunnels shows the exact commands).

**B. A small VPS (about $5/month, or a free-forever VM if your provider offers one).** Upload with `scp openchat.zip root@SERVER_IP:~`, SSH in, then follow steps 1 and 2 above. In GoDaddy DNS add an **A record**: host `chat` → server IP. Install Caddy for automatic HTTPS: a Caddyfile with `chat.yourdomain.com { reverse_proxy localhost:3000 }`.

Open the site and sign in: the first account becomes the admin. **Back up `data.db` regularly.**

## 3. Safety built in
- Campaigns reach **only opted-in contacts**; consent is re-checked at send time.
- STOP/UNSUBSCRIBE opts out instantly; START opts back in.
- Throttled sending (`SEND_GAP_MS`), rolling 24h cap (`DAILY_LIMIT`, default 250), auto-pause if more than 10% of sends fail.
- Free-form replies are blocked after the 24-hour window.
- `/join` is your public opt-in page (share the link on your site or social). It doesn't verify the number, so ask new subscribers to reply START on WhatsApp as proof.

Also: relevant content only, raise volume slowly, watch your quality rating in Meta Business Manager, never buy lists, never use unofficial WhatsApp libraries.

## Not included
Media messages, visual flow builder, label editing screen.

## Credentials you must add (`.env`)
Required: `WA_PHONE_ID`, `WA_TOKEN`, `APP_SECRET`, `VERIFY_TOKEN` (Meta WhatsApp Cloud API). Optional: `ANTHROPIC_API_KEY` for AI replies. Nothing else. The **Setup** tab shows what's connected and sends a test message.

## Update: no file editing for credentials
Admins paste the Meta and Anthropic values into the **Setup** tab; they're stored on your server (values in `.env` still work as a fallback). Teammates join through **Team, Create invite link** (one-time, valid 7 days). Phones can install the site via "Add to Home Screen".

## Team on WhatsApp
Each teammate saves their WhatsApp number (Setup tab, or on the invite page). Every customer message is relayed to the number of every teammate; the **first one to read it or reply to it** (long-press, Reply) takes the chat, and later messages go only to them. Opening the chat on the website also takes it. Admins can release or reassign. The customer only ever sees your business number.
Rules from Meta: free-text alerts work if the teammate messaged the business number in the last 24 hours. Otherwise create a **utility template** with two variables, e.g. `New WhatsApp message from {{1}}: {{2}}. Reply to this message to answer.`, get it approved, and enter its name in Setup.

## New and old customers
Any number that messages you is saved automatically and alerts the team. Old customers can be added by CSV on the Contacts tab; set the default country code in Setup so numbers like `0700...` match the number WhatsApp reports. Old WhatsApp chat history can't be imported (Meta's API doesn't provide it). Duplicate webhook deliveries are ignored.

## Assigning chats
In the Inbox, use **Assign to…** to give a chat to any teammate (or back to Unassigned). The new owner gets it on their WhatsApp ("Name assigned you this chat…"); they reply to that message to answer. The person handling a chat, or an admin, can reassign it.
