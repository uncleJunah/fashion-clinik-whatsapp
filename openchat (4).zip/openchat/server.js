const express=require('express'),crypto=require('crypto'),Database=require('better-sqlite3');
const E=process.env,db=new Database(E.DB_PATH||'data.db');db.pragma('journal_mode=WAL');
db.exec(`create table if not exists users(id integer primary key,email text unique,name text,pass text,role text default 'agent');
create table if not exists contacts(id integer primary key,phone text unique,name text default '',labels text default '',opted_in int default 0,opted_out int default 0,consent_source text,consent_at text,bot int default 1,last_in integer default 0,last_msg text default '');
create table if not exists messages(id integer primary key,contact_id int,dir text,body text,wa_id text,status text default 'sent',ts integer,user_id int);
create table if not exists automations(id integer primary key,keyword text,reply text);
create table if not exists campaigns(id integer primary key,name text,template text,lang text,status text default 'running',sent int default 0,failed int default 0,total int default 0,created integer);
create table if not exists queue(id integer primary key,campaign_id int,contact_id int,done int default 0);`);
for(const s of['alter table campaigns add column vars text','alter table contacts add column assigned int','alter table users add column phone text','alter table users add column last_in integer default 0'])try{db.exec(s)}catch{}
db.exec('create table if not exists products(id integer primary key,name text,price text,descr text);create table if not exists settings(k text primary key,v text);create table if not exists invites(token text primary key,role text,created integer);create table if not exists notifs(wa_id text primary key,contact_id int,user_id int)');
const app=express(),SECRET=E.SESSION_SECRET||crypto.randomBytes(32).toString('hex');
app.set('trust proxy',1);app.use(express.json({verify:(q,_,b)=>q.raw=b}));app.use(express.static('public'));
const hash=(p,s=crypto.randomBytes(16).toString('hex'))=>s+':'+crypto.scryptSync(p,s,32).toString('hex');
const check=(p,h)=>{const a=Buffer.from(hash(p,h.split(':')[0])),b=Buffer.from(h);return a.length===b.length&&crypto.timingSafeEqual(a,b)};
const sign=v=>v+'.'+crypto.createHmac('sha256',SECRET).update(v).digest('hex');
const get=(s,...a)=>db.prepare(s).get(...a),all=(s,...a)=>db.prepare(s).all(...a),run=(s,...a)=>db.prepare(s).run(...a);
const cfg=k=>get('select v from settings where k=?',k)?.v||E[k]||'';
const phone=p=>{let d=String(p||'').replace(/\D/g,'');if(d.startsWith('00'))d=d.slice(2);const cc=cfg('DEFAULT_CC').replace(/\D/g,'');if(cc&&d.startsWith('0'))d=cc+d.slice(1);return d};
async function wa(body){if(!cfg('WA_PHONE_ID')||!cfg('WA_TOKEN'))throw new Error('WhatsApp is not connected yet. Add your credentials in the Setup tab.');const r=await fetch(`https://graph.facebook.com/v21.0/${cfg('WA_PHONE_ID')}/messages`,{method:'POST',headers:{Authorization:'Bearer '+cfg('WA_TOKEN'),'Content-Type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',...body})});const j=await r.json();if(!r.ok)throw new Error(j.error?.message||'Send failed');return j.messages?.[0]?.id}
const log=(cid,dir,body,wid,uid)=>run('insert into messages(contact_id,dir,body,wa_id,ts,user_id) values(?,?,?,?,?,?)',cid,dir,body,wid,Date.now(),uid||null);
async function reply(c,t,uid){try{const id=await wa({to:c.phone,type:'text',text:{body:t}});log(c.id,'out',t,id,uid);run('update contacts set last_msg=? where id=?',t,c.id)}catch(e){console.error(e.message)}}

// ---- Team on WhatsApp: customer messages go to every teammate's WhatsApp; first to read or reply takes the chat
const claim=(cid,uid)=>run('update contacts set assigned=?,bot=0 where id=? and assigned is null',uid,cid).changes>0;
const tell=async(u,t)=>{try{await wa({to:u.phone,type:'text',text:{body:t}})}catch(e){console.error(e.message)}};
async function alertUser(u,c,text,pre=''){const who=(c.name||'+'+c.phone).slice(0,60);try{let id;
if(Date.now()-u.last_in<864e5)id=await wa({to:u.phone,type:'text',text:{body:(pre+who+': '+text).slice(0,900)+'\n\nReply to this message to answer the customer.'}});
else if(cfg('NOTIFY_TEMPLATE'))id=await wa({to:u.phone,type:'template',template:{name:cfg('NOTIFY_TEMPLATE'),language:{code:cfg('NOTIFY_LANG')||'en'},components:[{type:'body',parameters:[{type:'text',text:who},{type:'text',text:(pre+text).replace(/\s+/g,' ').slice(0,300)}]}]}});
if(id)run('insert into notifs values(?,?,?)',id,c.id,u.id)}catch(e){console.error(e.message)}}
async function notify(c,text){for(const u of all("select * from users where phone is not null and phone!=''").filter(u=>!c.assigned||u.id===c.assigned))await alertUser(u,c,text)}
async function staffMsg(u,m){const n=m.context?.id&&get('select * from notifs where wa_id=?',m.context.id);
if(!n)return tell(u,'To answer a customer, press and hold their message here and tap Reply.');
const c=get('select * from contacts where id=?',n.contact_id);
if(c.assigned&&c.assigned!==u.id)return tell(u,(get('select name from users where id=?',c.assigned)?.name||'A teammate')+' is already handling this chat.');
if(!m.text?.body)return tell(u,'Only text replies are supported for now.');
claim(c.id,u.id);if(Date.now()-c.last_in>864e5)return tell(u,'The 24-hour window with this customer is closed. Send a template from the web inbox.');
await reply(c,m.text.body,u.id)}
// ---- WhatsApp webhook (signature verified)
app.get('/webhook',(q,r)=>q.query['hub.verify_token']===cfg('VERIFY_TOKEN')?r.send(q.query['hub.challenge']):r.sendStatus(403));
app.post('/webhook',async(q,r)=>{const sig=q.headers['x-hub-signature-256']||'',ok='sha256='+crypto.createHmac('sha256',cfg('APP_SECRET')||'x').update(q.raw||'').digest('hex');
if(sig.length!==ok.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(ok)))return r.sendStatus(401);r.sendStatus(200);
for(const en of q.body.entry||[])for(const ch of en.changes||[]){const v=ch.value||{};
for(const s of v.statuses||[]){run('update messages set status=? where wa_id=?',s.status,s.id);if(s.status==='read'){const n=get('select * from notifs where wa_id=?',s.id);if(n)claim(n.contact_id,n.user_id)}}
for(const m of v.messages||[]){if(get('select 1 x from messages where wa_id=?',m.id))continue;const sf=get('select * from users where phone=?',phone(m.from));if(sf){run('update users set last_in=? where id=?',Date.now(),sf.id);log(0,'staff',m.text?.body||'',m.id);await staffMsg(sf,m);continue}
run(`insert into contacts(phone,name) values(?,?) on conflict(phone) do update set name=coalesce(nullif(name,''),excluded.name)`,m.from,v.contacts?.[0]?.profile?.name||'');
const c=get('select * from contacts where phone=?',m.from),t=m.text?.body||'['+m.type+']';
run('update contacts set last_in=?,last_msg=? where id=?',Date.now(),t,c.id);log(c.id,'in',t,m.id);await notify(get('select * from contacts where id=?',c.id),t);await handle(c,t.trim())}}});
async function handle(c,t){const k=t.toLowerCase();
if(['stop','unsubscribe','cancel'].includes(k)){run('update contacts set opted_out=1 where id=?',c.id);return reply(c,'You are unsubscribed and will get no more campaigns. Reply START to subscribe again.')}
if(['start','subscribe'].includes(k)){run("update contacts set opted_in=1,opted_out=0,consent_source='customer replied START',consent_at=? where id=?",new Date().toISOString(),c.id);return reply(c,'You are subscribed. Reply STOP any time to opt out.')}
const a=all('select * from automations').find(a=>k.includes(a.keyword.toLowerCase()));
if(a)return reply(c,a.reply);if(cfg('ANTHROPIC_API_KEY')&&c.bot)return reply(c,await ai(c))}
async function ai(c){const f='Thanks! A team member will reply shortly.';try{const h=all('select dir,body from messages where contact_id=? order by id desc limit 10',c.id).reverse().map(m=>({role:m.dir==='in'?'user':'assistant',content:m.body}));while(h.length&&h[0].role!=='user')h.shift();
const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'x-api-key':cfg('ANTHROPIC_API_KEY'),'anthropic-version':'2023-06-01','content-type':'application/json'},body:JSON.stringify({model:cfg('AI_MODEL')||'claude-sonnet-5-5',max_tokens:400,system:cfg('AI_PROMPT')||'You are a concise support assistant.',messages:h})});
return(await r.json()).content?.[0]?.text||f}catch{return f}}

// ---- Public opt-in form (/join)
const hits={};app.post('/join',(q,r)=>{const now=Date.now();hits[q.ip]=(hits[q.ip]||[]).filter(t=>now-t<36e5);if(hits[q.ip].length>=10)return r.status(429).json({error:'Too many tries. Try again later.'});hits[q.ip].push(now);
const{phone:p,name,consent}=q.body||{},n=phone(p);if(n.length<8||!consent)return r.status(400).json({error:'Enter a valid number and tick the consent box.'});
run(`insert into contacts(phone,name,opted_in,opted_out,consent_source,consent_at) values(?,?,1,0,'web form',?) on conflict(phone) do update set opted_in=1,opted_out=0,consent_source='web form',consent_at=excluded.consent_at`,n,String(name||'').slice(0,80),new Date().toISOString());r.json({ok:1})});
app.post('/invite/accept',(q,r)=>{const{token,name,email,password,phone:ph}=q.body||{},i=get('select * from invites where token=?',token);
if(!i||Date.now()-i.created>6048e5)return r.status(400).json({error:'This invite link has expired. Ask your admin for a new one.'});
if(!name||!email||!password||password.length<8)return r.status(400).json({error:'Fill every field. The password needs 8 or more characters.'});
try{run('insert into users(email,name,pass,role,phone) values(?,?,?,?,?)',email,name,hash(password),i.role,phone(ph));run('delete from invites where token=?',token);r.json({ok:1})}catch{r.status(400).json({error:'That email is already registered.'})}});
// ---- Auth
app.post('/api/login',(q,r)=>{const{email,password,name}=q.body||{};if(!email||!password)return r.status(400).json({error:'Enter email and password'});
if(!get('select count(*) n from users').n)run('insert into users(email,name,pass,role) values(?,?,?,?)',email,name||'Admin',hash(password),'admin');
const u=get('select * from users where email=?',email);if(!u||!check(password,u.pass))return r.status(401).json({error:'Wrong email or password'});
r.setHeader('Set-Cookie','s='+sign(u.id+'.'+(Date.now()+6048e5))+'; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800'+(E.NODE_ENV==='production'?'; Secure':''));r.json({ok:1})});
app.post('/api/logout',(q,r)=>{r.setHeader('Set-Cookie','s=; Path=/; Max-Age=0');r.json({ok:1})});
app.use('/api',(q,r,n)=>{const c=(q.headers.cookie||'').match(/s=([^;]+)/);if(c){const[id,exp]=c[1].split('.');if(sign(id+'.'+exp)===c[1]&&+exp>Date.now()&&(q.user=get('select * from users where id=?',id)))return n()}r.status(401).json({error:'Sign in'})});
const admin=(q,r,n)=>q.user.role==='admin'?n():r.status(403).json({error:'Admins only'});
app.get('/api/me',(q,r)=>r.json({id:q.user.id,name:q.user.name,role:q.user.role}));
app.get('/api/team',(q,r)=>r.json(all('select id,name from users')));
app.post('/api/me/phone',(q,r)=>{run('update users set phone=? where id=?',phone(q.body.phone),q.user.id);r.json({ok:1})});
app.get('/api/users',admin,(q,r)=>r.json(all('select id,email,name,role,phone from users')));
app.post('/api/users',admin,(q,r)=>{try{const{email,name,password,role,phone:ph}=q.body;run('insert into users(email,name,pass,role,phone) values(?,?,?,?,?)',email,name,hash(password),role==='admin'?'admin':'agent',phone(ph));r.json({ok:1})}catch(e){r.status(400).json({error:e.message})}});
app.delete('/api/users/:id',admin,(q,r)=>{if(+q.params.id!==q.user.id)run('delete from users where id=?',q.params.id);r.json({ok:1})});

// ---- Contacts & inbox
app.get('/api/contacts',(q,r)=>{const s='%'+(q.query.q||'')+'%';r.json(all(`select c.*,u.name assignee from contacts c left join users u on u.id=c.assigned where (c.name like ? or c.phone like ?)${q.query.inbox?" and c.last_msg!=''":''} order by c.last_in desc,c.id desc limit 500`,s,s))});
app.post('/api/contacts',(q,r)=>{let n=0;for(const c of Array.isArray(q.body)?q.body:[q.body]){const p=phone(c.phone);if(p.length<8)continue;
run(`insert into contacts(phone,name,labels,opted_in,consent_source,consent_at) values(?,?,?,?,?,?) on conflict(phone) do update set name=coalesce(nullif(excluded.name,''),name),labels=excluded.labels`,p,c.name||'',c.labels||'',c.consent?1:0,c.consent?c.source||'manual':null,c.consent?new Date().toISOString():null);n++}r.json({added:n})});
app.patch('/api/contacts/:id',(q,r)=>{const{optin,source}=q.body;if(optin)run("update contacts set opted_in=1,opted_out=0,consent_source=?,consent_at=? where id=?",source||'manual',new Date().toISOString(),q.params.id);else run('update contacts set opted_out=1 where id=?',q.params.id);r.json({ok:1})});
app.get('/api/messages/:id',(q,r)=>{claim(+q.params.id,q.user.id);r.json(all('select m.*,u.name agent from messages m left join users u on u.id=m.user_id where m.contact_id=? order by m.id',q.params.id))});
app.post('/api/messages/:id',async(q,r)=>{const c=get('select * from contacts where id=?',q.params.id);if(!c)return r.sendStatus(404);
if(Date.now()-c.last_in>864e5)return r.status(409).json({error:'The 24-hour reply window is closed. Send an approved template from Campaigns.'});
if(c.assigned&&c.assigned!==q.user.id)return r.status(403).json({error:(get('select name from users where id=?',c.assigned)?.name||'A teammate')+' is handling this chat.'});run('update contacts set bot=0 where id=?',c.id);claim(c.id,q.user.id);await reply(c,q.body.text,q.user.id);r.json({ok:1})});

// ---- Credentials saved in-app (admin only) & invite links
const KEYS=['WA_PHONE_ID','WA_TOKEN','APP_SECRET','VERIFY_TOKEN','ANTHROPIC_API_KEY','AI_PROMPT','NOTIFY_TEMPLATE','NOTIFY_LANG','DEFAULT_CC'],HIDE=['WA_TOKEN','APP_SECRET','ANTHROPIC_API_KEY'];
app.get('/api/settings',admin,(q,r)=>r.json(Object.fromEntries(KEYS.map(k=>[k,HIDE.includes(k)&&cfg(k)?'••••'+cfg(k).slice(-4):cfg(k)]))));
app.post('/api/settings',admin,(q,r)=>{for(const k of KEYS){const v=String(q.body[k]??'').trim();if(v&&!v.startsWith('••••'))run('insert into settings(k,v) values(?,?) on conflict(k) do update set v=excluded.v',k,v)}r.json({ok:1})});
app.post('/api/invites',admin,(q,r)=>{const t=crypto.randomBytes(18).toString('hex');run('insert into invites values(?,?,?)',t,q.body.role==='admin'?'admin':'agent',Date.now());r.json({token:t})});
// ---- Setup status & first-contact templates
app.get('/api/status',async(q,r)=>{const s={whatsapp:!!(cfg('WA_PHONE_ID')&&cfg('WA_TOKEN')),secret:!!cfg('APP_SECRET'),verify:!!cfg('VERIFY_TOKEN'),ai:!!cfg('ANTHROPIC_API_KEY')};
if(s.whatsapp)try{const x=await fetch(`https://graph.facebook.com/v21.0/${cfg('WA_PHONE_ID')}?fields=display_phone_number,verified_name,quality_rating`,{headers:{Authorization:'Bearer '+cfg('WA_TOKEN')}}),j=await x.json();if(x.ok)s.number=j;else s.error=j.error?.message}catch(e){s.error=e.message}
r.json(s)});
app.post('/api/messages/:id/template',async(q,r)=>{const c=get('select * from contacts where id=?',q.params.id);if(!c)return r.sendStatus(404);
if(!c.opted_in||c.opted_out)return r.status(409).json({error:'This contact has not given consent to receive templates.'});
try{const id=await wa({to:c.phone,type:'template',template:{name:q.body.name,language:{code:q.body.lang||'en_US'}}});log(c.id,'out','[template] '+q.body.name,id,q.user.id);run('update contacts set last_msg=? where id=?','[template] '+q.body.name,c.id);r.json({ok:1})}catch(e){r.status(502).json({error:e.message})}});
// ---- Catalogue & assignment
app.get('/api/products',(q,r)=>r.json(all('select * from products')));
app.post('/api/products',(q,r)=>{run('insert into products(name,price,descr) values(?,?,?)',q.body.name,q.body.price,q.body.descr);r.json({ok:1})});
app.delete('/api/products/:id',(q,r)=>{run('delete from products where id=?',q.params.id);r.json({ok:1})});
app.post('/api/contacts/:id/assign',async(q,r)=>{const c=get('select * from contacts where id=?',q.params.id);if(!c)return r.sendStatus(404);
if(c.assigned&&c.assigned!==q.user.id&&q.user.role!=='admin')return r.status(403).json({error:'A teammate is handling this chat.'});
const to=q.body.to?+q.body.to:q.body.take?q.user.id:null;if(to&&!get('select 1 x from users where id=?',to))return r.status(400).json({error:'Unknown teammate'});
run('update contacts set assigned=?,bot=0 where id=?',to,c.id);
if(to&&to!==q.user.id){const u=get('select * from users where id=?',to),last=get("select body from messages where contact_id=? and dir='in' order by id desc limit 1",c.id);if(u.phone)await alertUser(u,c,last?.body||'(no message yet)',q.user.name+' assigned you this chat. ')}
r.json({ok:1})});
// ---- Automations
app.get('/api/automations',(q,r)=>r.json(all('select * from automations')));
app.post('/api/automations',(q,r)=>{run('insert into automations(keyword,reply) values(?,?)',q.body.keyword,q.body.reply);r.json({ok:1})});
app.delete('/api/automations/:id',(q,r)=>{run('delete from automations where id=?',q.params.id);r.json({ok:1})});

// ---- Campaigns: opted-in contacts only, throttled, daily cap, auto-pause on failures
app.get('/api/campaigns',(q,r)=>r.json(all('select * from campaigns order by id desc')));
app.post('/api/campaigns',(q,r)=>{const{name,template,lang,label,vars}=q.body;
const rows=all('select id,labels from contacts where opted_in=1 and opted_out=0').filter(c=>!label||c.labels.split(',').map(s=>s.trim()).includes(label));
const id=run('insert into campaigns(name,template,lang,total,created,vars) values(?,?,?,?,?,?)',name,template,lang||'en',rows.length,Date.now(),vars||'').lastInsertRowid;
db.transaction(()=>rows.forEach(c=>run('insert into queue(campaign_id,contact_id) values(?,?)',id,c.id)))();r.json({id,total:rows.length})});
app.post('/api/campaigns/:id/:act',(q,r)=>{run("update campaigns set status=? where id=? and status!='done'",q.params.act==='pause'?'paused':'running',q.params.id);r.json({ok:1})});
let busy=0;setInterval(async()=>{if(busy)return;busy=1;try{const c=get("select * from campaigns where status='running' order by id limit 1");if(!c)return;
if(get("select count(*) n from messages where dir='out' and body like '[template]%' and ts>?",Date.now()-864e5).n>=(+E.DAILY_LIMIT||250))return;
const j=get('select q.id qid,ct.id cid,ct.phone,ct.name,ct.opted_in,ct.opted_out from queue q join contacts ct on ct.id=q.contact_id where q.campaign_id=? and q.done=0 limit 1',c.id);
if(!j)return run("update campaigns set status='done' where id=?",c.id);
run('update queue set done=1 where id=?',j.qid);if(!j.opted_in||j.opted_out)return;
const vs=(c.vars||'').split(',').map(s=>s.trim()).filter(Boolean),tpl={name:c.template,language:{code:c.lang}};
if(vs.length)tpl.components=[{type:'body',parameters:vs.map(v=>({type:'text',text:v==='name'?(j.name||'there'):v}))}];
try{const id=await wa({to:j.phone,type:'template',template:tpl});log(j.cid,'out','[template] '+c.template,id);run('update campaigns set sent=sent+1 where id=?',c.id)}
catch(e){run('update campaigns set failed=failed+1 where id=?',c.id);const x=get('select sent,failed from campaigns where id=?',c.id);if(x.failed>=5&&x.failed/(x.sent+x.failed)>0.1)run("update campaigns set status='paused' where id=?",c.id)}}finally{busy=0}},+E.SEND_GAP_MS||1500);
app.listen(E.PORT||3000,()=>console.log('Running on :'+(E.PORT||3000)));
